from setuptools import setup, find_packages
from glob import glob

setup(
    name="eazy_patex",
    version="1.0.1",
    author="Oleg Zagorulko",
    author_email="zagorulkooa@gmail.com",
    description="test desc",
    license="MIT",
    url="https://github.com/brtbrr/python-course",
    packages=find_packages(),
    install_requires=[],
    keywords="key word",
)